# Handoff: Fairydoku – Feen-Logikpuzzle (Mobile Game)

## Overview
Fairydoku ist ein Logik-Puzzlespiel mit Feen-Thema (Elemente aus Sudoku, Minesweeper und dem "Queens"-Puzzle). Der Spieler ist Hüter:in eines magischen Waldes und platziert Feen auf einem moosbewachsenen Gitter, das in leuchtende, farbcodierte Zonen unterteilt ist. Endlos-Modus: Mit jedem Level wird das Gitter größer und die Feen-Art wechselt.

## About the Design Files
Die Dateien in diesem Paket sind **Design-Referenzen in HTML** — ein funktionierender Prototyp, der Aussehen und Verhalten zeigt, aber KEIN Produktionscode zum direkten Übernehmen. Aufgabe: Dieses Design in der Zielumgebung nachbauen (React, Flutter, Unity, native Android/iOS, …) mit deren etablierten Patterns. Falls noch keine Umgebung existiert, wähle das passendste Framework für ein Mobile-Casual-Game (z. B. Flutter oder React Native; für reine Web-Auslieferung React).

`Fairydoku.dc.html` öffnet direkt im Browser und ist voll spielbar — die komplette Spiellogik (Puzzle-Generierung, Konfliktprüfung, Power-ups, Timer, Level-Progression) steckt in der `class Component` im `<script>`-Block der Datei und kann 1:1 als Referenz-Algorithmus übernommen werden.

## Fidelity
**High-fidelity.** Farben, Typografie, Abstände, Copy und Interaktionen sind final gemeint und sollen pixelgenau nachgebaut werden. Einzige Ausnahme: Die Feen sind aktuell Emoji-Platzhalter (🧚 mit CSS-Huerotation je Art) — im finalen Spiel durch illustrierte Feen-Sprites ersetzen (Stil: cute, schimmernde Flügel, Sparkle-Effekt, siehe `referenz-screenshot.png`).

## Screens / Views

Die App hat zwei Screens: **Levelkarte** (Startscreen) und **Spielbildschirm**. Beide teilen sich Hintergrund, Titel und Glühwürmchen-Layer. Scrollbars sind global ausgeblendet (\`scrollbar-width: none\` + \`::-webkit-scrollbar { display: none }\`); gescrollt wird per Touch/Wheel.

### 0. Levelkarte „Der Feenpfad" (Startscreen)
- **Kopf**: Badge mit Wald-Leben (💚 verbleibend / 🖤 verbraucht, max. 5) und — falls < 5 — Countdown „+💚 in m:ss" in Rosa; darunter Score-Badge; Überschrift „✦ Der Feenpfad ✦" (Cinzel Decorative 700, 19 px, Creme-Gold-Verlauf mit Glow); Hinweiszeile (13 px, \`#c9c2ff\`).
- **Karten-Panel**: Moos-Rahmen wie das Spielbrett (Padding 10 px, \`border-radius: 26px\`, grüne Gradients, Border \`rgba(140,190,90,.4)\`), darin ein vertikal scrollender Waldpfad (374 px breit, 470 px sichtbar, \`border-radius: 18px\`, dunkler Waldgrund \`linear-gradient(165deg,#16281c,#101f16 55%,#0d1a1e)\` + grüne/violette Radial-Glows, \`inset 0 0 34px rgba(0,0,0,.7)\`).
- **Pfad**: Sinuskurve durch die Level-Knoten (x = Mitte + 118·sin(i·1.05), Abstand 92 px vertikal, Level 1 oben). Gezeichnet als SVG: gepunktete goldene Linie (\`rgba(255,233,168,.35)\`, 5 px, dasharray 1 14) über breiterem weichem Schein (11 px, \`rgba(255,233,168,.12)\`).
- **Level-Knoten** (54 px Kreise, zentrierte Nummer, Quicksand 700 19 px):
  - *Abgeschlossen*: Steinplatten-Textur (wie Spielfeld-Zellen), \`3px\` Neon-Border in Zonenfarbe (Palette rotierend, 80 % Farbe + 20 % Weiß), farbiger Außen- und Innen-Glow, Nummer \`#fff2c9\` mit farbigem Text-Glow.
  - *Aktuelles Level*: Stein-Textur, weiß-goldene Border, kräftiger Gold-Glow außen+innen, \`glowPulse\`-Animation 1.6 s.
  - *Gesperrt*: dunkler Stein (\`#313b34→#222a25\`), schwache Border, 🔒 in \`rgba(255,255,255,.4)\`.
- **Deko im Pfad**: weichgezeichnete leuchtende Pilze 🍄 und Farne 🌿 (\`blur(1–1.5px)\` + farbige drop-shadows, Opacity ~.4) an den Rändern, dazu 3 twinkelnde Glühwürmchen-Punkte. Im Zielspiel durch illustrierte Assets ersetzen.
- **Interaktion**: Tap auf freigeschaltetes/abgeschlossenes Level startet es (vergangene Level jederzeit wiederholbar). Tap auf gesperrtes Level → Meldung „🌫️ Dieser Pfad ist noch von Nebel verhüllt…". Ohne Wald-Leben → Meldung mit Countdown.

### 1. Spielbildschirm (Hochformat 430 px Breite)
Vertikaler Flex-Stack, zentriert, `gap: 12px`, Padding `20px 18px 30px`.

- **Hintergrund**: Blaugrün-violetter, "gemalter" Nachtwald aus geschichteten Radial-Gradients (rosa/violette Glows unten links/rechts, türkis/blaue seitlich, dunkles Petrol oben) über `linear-gradient(180deg,#0a2032,#12283e 40%,#1c1f4a 75%,#241a4a)`. Basisfarbe `#0a0e21`. Dekorativ: 3 große, weichgezeichnete leuchtende Pilze (`blur(2–2.5px)` + farbiger `drop-shadow`, Opacity .35–.5) an den Rändern — im Zielspiel durch illustrierte Hintergrund-Pilze ersetzen. Exakte Werte siehe HTML.
- **Glühwürmchen-Layer**: 16 kleine Punkte (3–7 px, `#ffe9a8`, `box-shadow: 0 0 8px 2px rgba(255,233,168,.8)`), absolut positioniert, `twinkle`-Animation (Opacity .15→.9, Scale .7→1.15, 2.2–5 s, versetzte Delays), `pointer-events: none`.
- **Titel**: „Fairydoku", Cinzel Decorative 900, 36 px, Creme-Gold-Verlaufstext (`linear-gradient(180deg,#fffbe8,#ffedb0 45%,#f2c060)` via background-clip) mit weichem Glow (`drop-shadow 0 0 14px rgba(255,225,150,.55)` + dunkler Schlagschatten), flankiert von ✦-Funkeln (`#ffe9a8`, Glow) und zwei Feen-Avataren (32 px, `floaty`-Animation translateY 0→−7 px 3.4 s, zweiter 1.2 s Delay, rosa/blauer Glow).
- **Score-Badge**: „SCORE: {score}", abgerundetes Rechteck (`border-radius: 16px`, Padding `7px 22px`), Hintergrund `linear-gradient(180deg,#252b52,#151a38)`, Border `2px solid rgba(150,165,220,.45)`, Text `#f2ecff`, Quicksand 700, 16 px, `letter-spacing: 1.5px`, Schatten + heller Inset oben. Daneben **Level-Badge** gleicher Bauart mit Gold-Border `rgba(255,215,107,.4)` und Text `#ffe9a8`, 15 px.
- **Fortschrittsbalken** (250 px breit, 10 px hoch): Track `rgba(0,0,0,.4)` + Border `rgba(255,255,255,.12)`; Füllung Gold-Gradient `linear-gradient(90deg,#ffd76b,#ffe9a8)`, Glow, `transition: width .3s`. Breite = platzierte Feen / Gittergröße. Label darunter (11 px, 75 % Opacity): „{n} / {N} {Feenart} platziert".
- **Statuszeile**: Leben als 🍃 (verbleibend) + 🥀 (verloren); Timer-Pill „⏳ m:ss" (bei < 20 s Farbe `#ff8095`; eingefroren „🌸 m:ss" in `#ff9ecf` mit Glow); bei aktivem Schild grüner Hinweis „🍃 Schild aktiv" (`#7dff9e`, Glow).
- **Spielbrett-Rahmen**: Moos-Matte um das Grid — Padding 12 px, `border-radius: 22px`, grüne Gradients (`linear-gradient(160deg,#42562f,#2c3d20 60%,#22301a)` + helle Radial-Highlights), Border `2px solid rgba(140,190,90,.4)`, außen dunkler Schatten + grüner Glow, innen helles Moos-Inset. Darin das eigentliche **Grid**: CSS-Grid, Zellgröße `floor(352 / N)` px, Padding 5 px, `border-radius: 14px`, Hintergrund `rgba(12,18,10,.55)`, `inset 0 0 20px rgba(0,0,0,.65)`.
- **Zellen** (Steinplatten mit Moosflecken): Schachbrett-Variation aus mehrschichtigen Radial-Gradients — Basis graugrüner Stein, leicht zonengetönt (`color-mix(in oklab, {Zonenfarbe} 10%, #6a7561)` → `color-mix(… 8%, #48523f)`), darüber weißes Licht-Highlight (rgba(255,255,255,.16–.22)) und 2 dunkelgrüne Moos-Flecken (rgba(58–72,88–108,44–52,.45–.6)) an wechselnden Positionen; Stein-Relief via `inset 0 2px 5px rgba(255,255,255,.14), inset 0 -4px 9px rgba(0,0,0,.4)`.
- **Zonen-Ränder (Neon)**: Jede Zellseite bekommt `3.5px solid` — an Zonengrenzen/Außenkanten die aufgehellte Neon-Zonenfarbe (`color-mix(in oklab, {Zonenfarbe} 80%, white)`), innen `rgba(0,0,0,.35)`. Zusätzlich pro Grenzseite ein farbiger Inset-Glow (`inset ±4px 0 10px -2px {Zonenfarbe}`), sodass jede Zone wie ein leuchtender Neon-Rahmen wirkt. **Ecken-Rundung**: Wo zwei Grenzseiten aufeinandertreffen, bekommt die Zell-Ecke `border-radius: 14px` (sonst 2px) — Zonen erscheinen als abgerundete leuchtende Blöcke wie im Referenzbild. Zonen-Palette (in Reihenfolge): `#ff6b8a`, `#5bc8ff`, `#7dff9e`, `#ffd76b`, `#c58bff`, `#ff9a5b`, `#6bfff2`, `#ff9ecf`.
- **Zellinhalt**: Fee (Sprite, ~68 % der Zellgröße, `popIn`-Animation .35 s, doppelter Glow in Artfarbe, kräftig gesättigt) oder ✕-Markierung (~42 %, goldgelb `#ffe9a8` mit Gold-Glow) oder leer.
- **Konflikt-Zustand**: Zelle erhält `inset 0 0 18px rgba(255,60,90,.85)` + äußeren roten Glow, Transition .25 s.
- **Statusmeldung** unter dem Brett: 13 px, 600, `#c9c2ff` mit violettem Glow, zentriert; Default „Tippe ein Feld: leer → ✕ → 🧚", sonst Zonenname/Power-up-Feedback.
- **Power-up-Leiste**: 3 Buttons (je 86 px Spalte, `gap: 18px`): Icon-Kachel 66×66 px, `border-radius: 22px`, Hintergrund `linear-gradient(180deg,#4c5ca6,#2b3670 60%,#222c5e)`, Border `2.5px solid rgba(205,220,255,.7)`, Relief via hellem Inset oben + dunklem Inset unten (Candy-/Casual-Game-Look wie im Referenzbild); Count-Badge oben rechts (20 px Kreis in Akzentfarbe Gold/Grün/Rosa, dunkle Schrift, 12 px/700); Label darunter 12 px/700 zweizeilig in `#fff2c9` mit Schlagschatten. Hover: `translateY(-3px)`. Aktiver Schild: Kachel wird grün (`linear-gradient(180deg,#3d7a52,#245536 60%,#1c452c)`, Border `rgba(160,255,190,.85)`) mit `0 0 24px rgba(125,255,158,.65)`.
  1. ✨ „Feenstaub Hinweis"  2. 🍃 „Natur-Schild"  3. 🌸 „Zeiten-Blüte"

### 2. Overlays (absolut über dem Screen, `rgba(8,10,28,.8–.85)` + `backdrop-filter: blur(4px)`, z-index 20)
Karten: `linear-gradient(180deg,#232a5c,#171c42)`, `border-radius: 22px`, 1.5 px Akzent-Border, Padding ~28 px, Schatten `0 10px 40px rgba(0,0,0,.6)`. CTA-Button: Gold-Pill (`linear-gradient(180deg,#ffe9a8,#ffd76b)`, Text `#3a2604`, 700, 15 px, Glow), Hover `brightness(1.08)`.

- **Intro** („✨ Willkommen, Hüter:in ✨", Cinzel Decorative 21 px Gold): Regeln + Power-up-Erklärung, CTA „Den Wald betreten". Animation `riseUp` .45 s.
- **Level geschafft** („LEVEL UP!", 24 px Gold, pulsierendes 🧚‍♀️✨ 44 px): „Alle Feen leben in Harmonie!", „+{gained} Punkte" in `#7dff9e`, Teaser auf nächstes Level, CTA „Tiefer in den Wald →". Animation `popIn` .5 s.
- **Game Over** („Der Zauber verblasst…", `#ff9aac`, rote Border `rgba(255,120,140,.55)`, 🥀 40 px): Grund, Punkte/Level, Wald-Leben-Anzeige; CTA „Level neu starten" (nur bei ≥1 Wald-Leben, sonst Countdown „+💚 in m:ss") + Link „🗺️ Zur Karte".

## Interactions & Behavior
- **Zell-Tap zyklisch**: leer → ✕ (Notiz „hier keine Fee") → 🧚 Fee → leer. Nach jedem Tap wird der Zonenname der Zelle als Statusmeldung gezeigt.
- **Regeln (Konflikt)**: Zwei Feen kollidieren bei gleicher Reihe, gleicher Spalte, gleicher Zone oder Berührung (Chebyshev-Distanz ≤ 1, also auch diagonal). Beide Zellen glühen rot.
- **Fehler**: Erzeugt eine neu platzierte Fee einen Konflikt → −1 Level-Leben (Meldung „⚡ Die Zauberkräfte stören sich!"); bei aktivem Natur-Schild wird stattdessen der Schild verbraucht („🍃 Der Natur-Schild hat dich beschützt!"). 0 Level-Leben → Game Over.
- **Zwei Leben-Ebenen**:
  - *Level-Leben* (3, als 🍃/🥀 im Spiel): Fehlversuche innerhalb eines Levels.
  - *Wald-Leben* (5, global, als 💚/🖤): Jedes verlorene Level (Leben aufgebraucht ODER Zeit abgelaufen) kostet 1 Wald-Leben. Regeneration: alle 15 Minuten +1 (Timestamp-basiert, läuft auch offline weiter). Bei 0 Wald-Leben kann kein Level gestartet werden — Countdown bis zum nächsten Leben wird auf Karte und im Game-Over-Dialog angezeigt. Der Retry nach Game Over kostet kein zusätzliches Leben (bereits abgezogen).
- **Navigation**: 🗺️-Button neben dem Score führt zurück zur Karte (kein Lebensverlust beim Abbrechen); „Zur Karte"-Links in Level-Up- und Game-Over-Overlay.
- **Sieg**: Genau N Feen platziert, keine Konflikte → Level-Up-Overlay. Punkte: `100·N + Restsekunden·5`. Level wird als abgeschlossen markiert, nächstes freigeschaltet, Fortschritt gespeichert.
- **Power-ups**:
  - ✨ Feenstaub: Platziert eine Fee auf einem garantiert korrekten Feld der generierten Lösung; das Feld pulsiert 2 s golden (`glowPulse`). Im Zielspiel: Irrlicht-Kugel fliegt sichtbar über das Brett zum Feld.
  - 🍃 Natur-Schild: Toggle an; absorbiert den nächsten Fehler.
  - 🌸 Zeiten-Blüte: Friert den Timer 12 s ein (Timer-Anzeige wechselt auf 🌸/rosa).
  - Bei Count 0: nur Statusmeldung („Kein Feenstaub mehr übrig…" etc.), keine Aktion.
- **Timer**: Startwert `60 + N·15` Sekunden, tickt sekündlich; 0 → Game Over („Die Zeit ist verronnen…"). Optional deaktivierbar.
- **Level-Progression (Endlos)**: Gittergröße `min(8, startSize + floor((level−1)/2))` → 4,5,5,6,6,7,7,8,… Feen-Art rotiert pro Level: Blütenfeen (rosa Glow) → Wasserfeen (blau) → Feuerfeen (orange) → Sternenfeen (gold). Nach Level-Up: +1 Feenstaub, +1 Blüte, +1 Schild alle 2 Level.
- **Animationen**: Keyframes `twinkle`, `floaty`, `popIn` (Scale .3→1.15→1), `glowPulse`, `riseUp` (translateY 16 px→0 + Fade) — Dauer/Easing siehe Quelldatei.

## State Management
- `screen`: 'map' | 'game'; `phase`: 'intro' | 'ready' | 'play' | 'won' | 'over'
- Pro Level: `size` (N), `sol` (Lösungsspalte je Reihe), `regions` (N×N Zonen-Matrix), `cellState` (N² Einträge: '' | 'x' | 'f'), `speciesIdx`
- Laufwerte: `score`, `level`, `lives`, `timeLeft`, `freezeUntil` (Timestamp), `hintCount`, `shieldCount`, `blossomCount`, `shieldActive`, `zoneMsg`, `hintCell`, `gained`, `overReason`
- Progression: `unlocked` (höchstes freigeschaltetes Level), `completed` (Array), `globalLives` (0–5), `nextRegenAt` (Timestamp nächste Regeneration, 15-Min-Kette)
- Startwerte: 3 Level-Leben, 5 Wald-Leben, 3 Feenstaub, 1 Schild, 2 Blüten
- **Puzzle-Generierung** (siehe `genSolution`/`genRegions` in der HTML-Datei): (1) Zufällige Permutation per Backtracking, bei der aufeinanderfolgende Reihen Spaltenabstand ≥ 2 haben (erfüllt die Berührungsregel). (2) Zonen wachsen per zufälliger Flood-Fill von den N Lösungsfeldern als Seeds, bis das Gitter partitioniert ist. Garantiert mindestens eine Lösung.
- Konfigurierbar (im Prototyp als Tweaks-Props): `startSize` (4–6), `timerEnabled` (bool), `lives` (1–5)
- **Persistenz**: localStorage-Key `fairydoku_save` = `{unlocked, completed, globalLives, nextRegenAt, score, hintCount, shieldCount, blossomCount}`; wird bei Sieg, Game Over und Leben-Regeneration geschrieben und beim Start geladen (inkl. Offline-Nachregenerierung der Leben).

## Design Tokens
- **Farben**: Basis `#0a0e21`; Hintergrund-Wald `#0a2032→#12283e→#1c1f4a→#241a4a`; Badges/Panels `#252b52→#151a38`, Overlay-Karten `#232a5c→#171c42`; Power-up-Kacheln `#4c5ca6→#2b3670→#222c5e`; Moos-Rahmen `#42562f→#2c3d20→#22301a`; Stein `#6a7561`/`#48523f` (zonengetönt via color-mix); Text `#eae6ff`/`#f2ecff`; Gold-Akzent `#ffd76b` / hell `#ffe9a8`/`#fff2c9` / Verlauf `#fffbe8→#ffedb0→#f2c060`, Gold-Text auf Gold `#3a2604`; Grün `#7dff9e`; Rosa `#ff9ecf`; Fehler `#ff8095`/`rgba(255,60,90,.85)`; Zonen-Palette s. o. (Neon = 80 % Zonenfarbe + 20 % Weiß).
- **Typografie**: Cinzel Decorative (700/900) für Titel & Overlay-Headlines; Quicksand (400–700) für UI. Größen: 36/24/21 px Headlines; 16/15/13.5 px UI; 11–12 px Labels.
- **Radii**: Badges 16px, Icon-Kacheln 22px, Karten 22px, Moos-Rahmen 22px, Grid 14px, Zonen-Ecken 14px.
- **Schatten/Glows**: siehe Komponenten oben (Gold-Glow `0 0 14–22px rgba(255,215,107,…)` ist das Leitmotiv).
- **Spacing**: Stack-Gap 12px, Power-up-Gap 18px, Karten-Padding 26–28px.

## Assets
- Keine Bild-Assets im Prototyp — alles CSS/Emoji. Referenz-Artstyle: `referenz-screenshot.png` (KI-generierter Zielstil: cute Casual-Game-Art, biolumineszenter Wald, leuchtende Pilze).
- Zu produzieren: 4 Feen-Sprite-Sets (Blüten/Wasser/Feuer/Sternen), 3 Power-up-Icons (Feenstaub-Glas, leuchtendes Blatt, Uhrblume), Hintergrund-Illustration, optional Sound.
- Fonts: Google Fonts „Cinzel Decorative" + „Quicksand".

## Weiterbearbeitung im Design-Tool
`Fairydoku.dc.html` ist ein Design-Component-File: Es kann in einem Claude-Design-Projekt einfach als Datei hochgeladen/hineinkopiert werden und ist dort sofort lauffähig, spielbar und weiter editierbar (Chat-Anweisungen, Direktbearbeitung, Tweaks-Props `startSize`/`timerEnabled`/`lives`).

## Files
- `Fairydoku.dc.html` — spielbarer HTML-Prototyp (Markup zwischen `<x-dc>`-Tags, Logik als `class Component` im Script-Block; `support.js` ist nur Prototyp-Runtime und irrelevant fürs Zielspiel)
- `referenz-screenshot.png` — Ziel-Artstyle-Referenz

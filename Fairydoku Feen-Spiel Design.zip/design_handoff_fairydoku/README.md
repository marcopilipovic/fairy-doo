# Handoff: Fairydoku – Feen-Logikpuzzle (Mobile Game)

## Overview
Fairydoku ist ein Logik-Puzzlespiel mit Feen-Thema (Elemente aus Sudoku, Minesweeper und dem "Queens"-Puzzle). Der Spieler ist Hüter:in eines magischen Waldes und platziert Feen auf einem moosbewachsenen Gitter, das in leuchtende, farbcodierte Zonen unterteilt ist. Endlos-Modus: Mit jedem Level wird das Gitter größer und die Feen-Art wechselt.

## About the Design Files
Die Dateien in diesem Paket sind **Design-Referenzen in HTML** — ein funktionierender Prototyp, der Aussehen und Verhalten zeigt, aber KEIN Produktionscode zum direkten Übernehmen. Aufgabe: Dieses Design in der Zielumgebung nachbauen (React, Flutter, Unity, native Android/iOS, …) mit deren etablierten Patterns. Falls noch keine Umgebung existiert, wähle das passendste Framework für ein Mobile-Casual-Game (z. B. Flutter oder React Native; für reine Web-Auslieferung React).

`Fairydoku.dc.html` öffnet direkt im Browser und ist voll spielbar — die komplette Spiellogik (Puzzle-Generierung, Konfliktprüfung, Power-ups, Timer, Level-Progression) steckt in der `class Component` im `<script>`-Block der Datei und kann 1:1 als Referenz-Algorithmus übernommen werden.

## Fidelity
**High-fidelity.** Farben, Typografie, Abstände, Copy und Interaktionen sind final gemeint und sollen pixelgenau nachgebaut werden. Einzige Ausnahme: Die Feen sind aktuell Emoji-Platzhalter (🧚 mit CSS-Huerotation je Art) — im finalen Spiel durch illustrierte Feen-Sprites ersetzen (Stil: cute, schimmernde Flügel, Sparkle-Effekt, siehe `referenz-screenshot.png`).

## Screens / Views

### 1. Spielbildschirm (einziger Screen, Hochformat 430 px Breite)
Vertikaler Flex-Stack, zentriert, `gap: 12px`, Padding `20px 18px 30px`.

- **Hintergrund**: Tiefblau-violetter Nachtwald aus geschichteten Gradients:
  `radial-gradient(80% 55% at 20% 100%, rgba(255,107,180,.18), transparent 60%)`, `radial-gradient(70% 50% at 85% 95%, rgba(91,200,255,.16), transparent 60%)`, `radial-gradient(90% 70% at 50% -10%, #1c2650, transparent 70%)`, `linear-gradient(180deg, #0d1330, #141a3e 45%, #1b1440)`. Basisfarbe `#0a0e21`.
- **Glühwürmchen-Layer**: 16 kleine Punkte (3–7 px, `#ffe9a8`, `box-shadow: 0 0 8px 2px rgba(255,233,168,.8)`), absolut positioniert, `twinkle`-Animation (Opacity .15→.9, Scale .7→1.15, 2.2–5 s, versetzte Delays), `pointer-events: none`.
- **Titel**: „Fairydoku", Cinzel Decorative 900, 34 px, Gold-Verlaufstext (`linear-gradient(180deg,#fff3c8,#ffd76b 55%,#e9a53f)` via background-clip), Glow `text-shadow: 0 0 22px rgba(255,215,107,.35)`. Flankiert von zwei Feen-Avataren (30 px, sanfte `floaty`-Animation: translateY 0→−7 px, 3.4 s, zweiter mit 1.2 s Delay).
- **Score-Pill**: „SCORE: {score}", Pill (`border-radius: 999px`, Padding `6px 18px`), Hintergrund `linear-gradient(180deg,#2a2f5e,#1c2148)`, Border `1px solid rgba(255,215,107,.5)`, Glow `0 0 14px rgba(255,215,107,.18)`, Quicksand 700, 15 px, `letter-spacing: 1px`. Daneben **Level-Pill** gleicher Bauart mit grüner Border `rgba(125,255,158,.4)`, 14 px.
- **Fortschrittsbalken** (250 px breit, 10 px hoch): Track `rgba(0,0,0,.4)` + Border `rgba(255,255,255,.12)`; Füllung Gold-Gradient `linear-gradient(90deg,#ffd76b,#ffe9a8)`, Glow, `transition: width .3s`. Breite = platzierte Feen / Gittergröße. Label darunter (11 px, 75 % Opacity): „{n} / {N} {Feenart} platziert".
- **Statuszeile**: Leben als 🍃 (verbleibend) + 🥀 (verloren); Timer-Pill „⏳ m:ss" (bei < 20 s Farbe `#ff8095`; eingefroren „🌸 m:ss" in `#ff9ecf` mit Glow); bei aktivem Schild grüner Hinweis „🍃 Schild aktiv" (`#7dff9e`, Glow).
- **Spielbrett**: CSS-Grid, Zellgröße `floor(352 / N)` px, Container-Padding 4 px, `border-radius: 14px`, Hintergrund `rgba(10,14,30,.55)`, Schatten `0 8px 30px rgba(0,0,0,.5), 0 0 40px rgba(120,140,255,.12)`.
- **Zellen** (moosige Steinfelder): Schachbrett-Variation zweier Radial-Gradients — `radial-gradient(circle at 35% 30%, #4a5d3f, #35452e 70%)` bzw. `radial-gradient(circle at 60% 65%, #55684a, #3b4c33 70%)`; Stein-Relief via `inset 0 2px 6px rgba(255,255,255,.10), inset 0 -3px 8px rgba(0,0,0,.35)`.
- **Zonen-Ränder**: Jede Zellseite bekommt `2.5px solid` — Zonenfarbe an Zonengrenzen/Außenkanten, sonst `rgba(255,255,255,.10)`. Zonen-Palette (in Reihenfolge): `#ff6b8a`, `#5bc8ff`, `#7dff9e`, `#ffd76b`, `#c58bff`, `#ff9a5b`, `#6bfff2`, `#ff9ecf`.
- **Zellinhalt**: Fee (Sprite, ~58 % der Zellgröße, `popIn`-Animation .35 s, Glow-`text-shadow` in Artfarbe) oder ✕-Markierung (~34 %, `rgba(255,255,255,.45)`) oder leer.
- **Konflikt-Zustand**: Zelle erhält `inset 0 0 18px rgba(255,60,90,.8)`, Transition .25 s.
- **Statusmeldung** unter dem Brett: 13 px, 600, `#c9c2ff` mit violettem Glow, zentriert; Default „Tippe ein Feld: leer → ✕ → 🧚", sonst Zonenname/Power-up-Feedback.
- **Power-up-Leiste**: 3 Buttons (je 86 px Spalte, `gap: 18px`): Icon-Kachel 62×62 px, `border-radius: 18px`, Hintergrund `linear-gradient(180deg,#33407a,#1e2450)`, 2 px Border in Akzentfarbe (Gold `rgba(255,215,107,.55)` / Grün `rgba(125,255,158,.6)` / Rosa `rgba(255,158,207,.55)`), innerer Glow passend; Count-Badge oben rechts (20 px Kreis in Akzentfarbe, dunkle Schrift, 12 px/700); Label darunter 11.5 px/700 zweizeilig. Hover: `translateY(-3px)`. Aktiver Schild: Kachel wird grün (`linear-gradient(180deg,#2f6b45,#1d4a2e)`) mit `0 0 22px rgba(125,255,158,.6)`.
  1. ✨ „Feenstaub Hinweis"  2. 🍃 „Natur-Schild"  3. 🌸 „Zeiten-Blüte"

### 2. Overlays (absolut über dem Screen, `rgba(8,10,28,.8–.85)` + `backdrop-filter: blur(4px)`, z-index 20)
Karten: `linear-gradient(180deg,#232a5c,#171c42)`, `border-radius: 22px`, 1.5 px Akzent-Border, Padding ~28 px, Schatten `0 10px 40px rgba(0,0,0,.6)`. CTA-Button: Gold-Pill (`linear-gradient(180deg,#ffe9a8,#ffd76b)`, Text `#3a2604`, 700, 15 px, Glow), Hover `brightness(1.08)`.

- **Intro** („✨ Willkommen, Hüter:in ✨", Cinzel Decorative 21 px Gold): Regeln + Power-up-Erklärung, CTA „Den Wald betreten". Animation `riseUp` .45 s.
- **Level geschafft** („LEVEL UP!", 24 px Gold, pulsierendes 🧚‍♀️✨ 44 px): „Alle Feen leben in Harmonie!", „+{gained} Punkte" in `#7dff9e`, Teaser auf nächstes Level, CTA „Tiefer in den Wald →". Animation `popIn` .5 s.
- **Game Over** („Der Zauber verblasst…", `#ff9aac`, rote Border `rgba(255,120,140,.55)`, 🥀 40 px): Grund, „Endstand: {score} Punkte · Level {level}", CTA „Neuer Versuch".

## Interactions & Behavior
- **Zell-Tap zyklisch**: leer → ✕ (Notiz „hier keine Fee") → 🧚 Fee → leer. Nach jedem Tap wird der Zonenname der Zelle als Statusmeldung gezeigt.
- **Regeln (Konflikt)**: Zwei Feen kollidieren bei gleicher Reihe, gleicher Spalte, gleicher Zone oder Berührung (Chebyshev-Distanz ≤ 1, also auch diagonal). Beide Zellen glühen rot.
- **Fehler**: Erzeugt eine neu platzierte Fee einen Konflikt → −1 Leben (Meldung „⚡ Die Zauberkräfte stören sich!"); bei aktivem Natur-Schild wird stattdessen der Schild verbraucht („🍃 Der Natur-Schild hat dich beschützt!"). 0 Leben → Game Over.
- **Sieg**: Genau N Feen platziert, keine Konflikte → Level-Up-Overlay. Punkte: `100·N + Restsekunden·5`.
- **Power-ups**:
  - ✨ Feenstaub: Platziert eine Fee auf einem garantiert korrekten Feld der generierten Lösung; das Feld pulsiert 2 s golden (`glowPulse`). Im Zielspiel: Irrlicht-Kugel fliegt sichtbar über das Brett zum Feld.
  - 🍃 Natur-Schild: Toggle an; absorbiert den nächsten Fehler.
  - 🌸 Zeiten-Blüte: Friert den Timer 12 s ein (Timer-Anzeige wechselt auf 🌸/rosa).
  - Bei Count 0: nur Statusmeldung („Kein Feenstaub mehr übrig…" etc.), keine Aktion.
- **Timer**: Startwert `60 + N·15` Sekunden, tickt sekündlich; 0 → Game Over („Die Zeit ist verronnen…"). Optional deaktivierbar.
- **Level-Progression (Endlos)**: Gittergröße `min(8, startSize + floor((level−1)/2))` → 4,5,5,6,6,7,7,8,… Feen-Art rotiert pro Level: Blütenfeen (rosa Glow) → Wasserfeen (blau) → Feuerfeen (orange) → Sternenfeen (gold). Nach Level-Up: +1 Feenstaub, +1 Blüte, +1 Schild alle 2 Level.
- **Animationen**: Keyframes `twinkle`, `floaty`, `popIn` (Scale .3→1.15→1), `glowPulse`, `riseUp` (translateY 16 px→0 + Fade) — Dauer/Easing siehe Quelldatei.

## State Management
- `phase`: 'intro' | 'play' | 'won' | 'over'
- Pro Level: `size` (N), `sol` (Lösungsspalte je Reihe), `regions` (N×N Zonen-Matrix), `cellState` (N² Einträge: '' | 'x' | 'f'), `speciesIdx`
- Laufwerte: `score`, `level`, `lives`, `timeLeft`, `freezeUntil` (Timestamp), `hintCount`, `shieldCount`, `blossomCount`, `shieldActive`, `zoneMsg`, `hintCell`, `gained`, `overReason`
- Startwerte: 3 Leben, 3 Feenstaub, 1 Schild, 2 Blüten
- **Puzzle-Generierung** (siehe `genSolution`/`genRegions` in der HTML-Datei): (1) Zufällige Permutation per Backtracking, bei der aufeinanderfolgende Reihen Spaltenabstand ≥ 2 haben (erfüllt die Berührungsregel). (2) Zonen wachsen per zufälliger Flood-Fill von den N Lösungsfeldern als Seeds, bis das Gitter partitioniert ist. Garantiert mindestens eine Lösung.
- Konfigurierbar (im Prototyp als Tweaks-Props): `startSize` (4–6), `timerEnabled` (bool), `lives` (1–5)
- Keine Datenfetches; Highscore-Persistenz (localStorage o. Ä.) wäre sinnvolle Ergänzung.

## Design Tokens
- **Farben**: Basis `#0a0e21`; Panels `#2a2f5e→#1c2148`, Karten `#232a5c→#171c42`; Text `#eae6ff`; Gold-Akzent `#ffd76b` / hell `#ffe9a8` / dunkel `#e9a53f`, Gold-Text auf Gold `#3a2604`; Grün `#7dff9e`; Rosa `#ff9ecf`; Fehler `#ff8095`/`rgba(255,60,90,.8)`; Moos `#4a5d3f #35452e #55684a #3b4c33`; Zonen-Palette s. o.
- **Typografie**: Cinzel Decorative (700/900) für Titel & Overlay-Headlines; Quicksand (400–700) für UI. Größen: 34/24/21 px Headlines; 15/14/13.5 px UI; 11–12 px Labels.
- **Radii**: Pills 999px, Icon-Kacheln 18px, Karten 22px, Brett 14px.
- **Schatten/Glows**: siehe Komponenten oben (Gold-Glow `0 0 14–22px rgba(255,215,107,…)` ist das Leitmotiv).
- **Spacing**: Stack-Gap 12px, Power-up-Gap 18px, Karten-Padding 26–28px.

## Assets
- Keine Bild-Assets im Prototyp — alles CSS/Emoji. Referenz-Artstyle: `referenz-screenshot.png` (KI-generierter Zielstil: cute Casual-Game-Art, biolumineszenter Wald, leuchtende Pilze).
- Zu produzieren: 4 Feen-Sprite-Sets (Blüten/Wasser/Feuer/Sternen), 3 Power-up-Icons (Feenstaub-Glas, leuchtendes Blatt, Uhrblume), Hintergrund-Illustration, optional Sound.
- Fonts: Google Fonts „Cinzel Decorative" + „Quicksand".

## Files
- `Fairydoku.dc.html` — spielbarer HTML-Prototyp (Markup zwischen `<x-dc>`-Tags, Logik als `class Component` im Script-Block; `support.js` ist nur Prototyp-Runtime und irrelevant fürs Zielspiel)
- `referenz-screenshot.png` — Ziel-Artstyle-Referenz
